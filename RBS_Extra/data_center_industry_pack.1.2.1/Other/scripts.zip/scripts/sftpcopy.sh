#!/bin/bash

# SFTP server details
SFTP_USER="sftp"
SFTP_PASS="sftp"
SFTP_HOST="mySFTP"
REMOTE_DIR="/comtrade"
LOCAL_DIR="/usr/local/bin/ignition/webserver/webapps/comtrade/storage/sftp"

# Create the local directory if it does not exist
mkdir -p $LOCAL_DIR

# Create a temporary file to store SFTP commands
SFTP_COMMANDS=$(mktemp)

# Write SFTP commands to the temporary file
echo "lcd $LOCAL_DIR" > $SFTP_COMMANDS
echo "cd $REMOTE_DIR" >> $SFTP_COMMANDS
echo "mget -r *" >> $SFTP_COMMANDS

# Run SFTP with the commands from the temporary file using sshpass
sshpass -p $SFTP_PASS sftp -oBatchMode=no -oStrictHostKeyChecking=no -b $SFTP_COMMANDS $SFTP_USER@$SFTP_HOST

# Clean up the temporary file
rm $SFTP_COMMANDS

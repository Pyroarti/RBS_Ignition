from org.apache.commons.math3.fitting import WeightedObservedPoints, SimpleCurveFitter
from org.apache.commons.math3.analysis import ParametricUnivariateFunction
from java.lang import Math
import sys
import time
import math
from org.apache.commons.math3.transform import FastFourierTransformer, DftNormalization, TransformType
from org.apache.commons.math3.complex import Complex
import java.util.Arrays as Arrays
import java.util.stream.DoubleStream as DoubleStream
from java.util.function import DoubleUnaryOperator

system.util.getLogger('exchange.comtrade.comtradePhasorScript')

class SineFunction(ParametricUnivariateFunction):
	def value(self, x, params):
		A, f, phi, offset = params
		return A * Math.sin(2 * Math.PI * f * x + phi) + offset
	def gradient(self, x, params):
		A, f, phi, offset = params
		angle = 2 * Math.PI * f * x + phi
		return [
			Math.sin(angle),                    # d/dA
			A * Math.cos(angle) * (2 * Math.PI * x),  # d/df
			A * Math.cos(angle),                # d/dphi
			1                                  # d/doffset
		]

def calculatePhasorNew(voltage, samplingRate, fftSize):
	"""Simpler phasor calculation using raw FFT output:
	- Compute RMS from time-domain samples.
	- Compute FFT on the raw samples (no windowing, no zero-padding).
	- Use the FFT bin with maximum magnitude (up to Nyquist) as the detected frequency.

	This version prioritizes speed and returns minimal-processed FFT output:
	Returns: (magnitude, phaseShift, detectedFreq)
	"""
	transformer = FastFourierTransformer(DftNormalization.UNITARY)

	# Fast RMS calculation using a tight loop (avoid Java stream overhead)
	N = len(voltage)
	if N <= 0:
		return 0.0, None, 0.0

	sumsq = 0.0
	for v in voltage:
		try:
			sumsq += v * v
		except:
			logger.warn(str(voltage))
	rmsMagnitude = Math.sqrt(sumsq / float(N))
	magnitude = rmsMagnitude * Math.sqrt(2)

	# Raw FFT (no windowing, no zero-pad)
	fftResult = transformer.transform(voltage, TransformType.FORWARD)

	# Frequency resolution and Nyquist-limited max bin
	freqResolution = float(samplingRate) / N
	nyquistFreq = samplingRate / 2.0
	maxBin = int(nyquistFreq / freqResolution)
	if maxBin >= N:
		maxBin = N - 1

	# Find peak using magnitude squared to avoid sqrt
	maxMagSq = -1.0
	peakIndex = 0
	for i in range(1, maxBin + 1):
		real = fftResult[i].getReal()
		imag = fftResult[i].getImaginary()
		magSq = real*real + imag*imag
		if magSq > maxMagSq:
			maxMagSq = magSq
			peakIndex = i

	detectedFreq = peakIndex * freqResolution
	peakComplex = fftResult[peakIndex]

	# Compute single phase shift from the peak bin (same convention as calculatePhasor)
	real = peakComplex.getReal()
	imag = peakComplex.getImaginary()
	phaseShift = Math.atan2(imag, real) + Math.PI/2

	# Normalize to [-pi, pi]
	phaseShift = ((phaseShift + Math.PI) % (2 * Math.PI)) - Math.PI

	# Return magnitude, single phase shift, and detected frequency
	return magnitude , phaseShift, detectedFreq

# Main function
def parseDataset(dataset, samplingRate, sineFitting = True):
	# unpack dataset
	# to minimize error zero to first point
	zeroPoint = math.floor(dataset.getValueAt(0, 0))
	timePoints = [dataset.getValueAt(row, 0) - zeroPoint for row in xrange(dataset.getRowCount())]

	output = []
	for col in range(1, dataset.getColumnCount()):
		signal = [dataset.getValueAt(row, col) for row in xrange(dataset.getRowCount())]  # Extract signal values from dataset

		# find highest power of two number that is less than len(signal)
		pointsToUse = int(2**math.floor(math.log(len(signal), 2)))
		
		averageAmplitude, calculatedPhaseShift, combinedFrequency = calculatePhasorNew(signal[:pointsToUse], samplingRate, pointsToUse)
		calculatedOffset = 0

		# determine final values using sine fitting
		if sineFitting:
			obs = WeightedObservedPoints()
			for t, y in zip(timePoints, signal):
				obs.add(t, y)

			initial = [averageAmplitude, combinedFrequency, calculatedPhaseShift, 0.0]
			fitter = SimpleCurveFitter.create(SineFunction(), initial)
			bestParams = fitter.fit(obs.toList())
			
			averageAmplitude = bestParams[0]
			combinedFrequency = bestParams[1]
			if averageAmplitude >= 0:
				calculatedPhaseShift = bestParams[2] % (2 * Math.PI)
			else:
				# negative rms is not possible, shift by pi
				averageAmplitude *= -1.0
				calculatedPhaseShift = (bestParams[2] + Math.PI) % (2 * Math.PI)
			calculatedOffset = bestParams[3]

		output.append({
			'amplitude': averageAmplitude,
			'rmsAmplitude': averageAmplitude / Math.sqrt(2),
			'frequency': combinedFrequency,
			'phaseShift': calculatedPhaseShift,
			'phaseShiftDegrees': calculatedPhaseShift * (180.0 / Math.PI),
			'offset': calculatedOffset,
			'version': 18
		})

	bestFit = []
	for col in range(1, dataset.getColumnCount()):
		params = output[col-1]
		A = params['amplitude']
		f = params['frequency']
		phi = params['phaseShift']
		offset = params['offset']
		bestFit.append([A * Math.sin(2 * Math.PI * f * t + phi) + offset for t in timePoints])

	return output, bestFit
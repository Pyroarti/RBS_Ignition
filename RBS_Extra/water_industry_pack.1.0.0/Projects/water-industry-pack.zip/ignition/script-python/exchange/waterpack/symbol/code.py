def getStateStyle(stateValue):
	#return style class based on state
	
	if stateValue == 0:
		styleClass = "exchange/water-pack/components/symbol-state/stopped"
	elif stateValue == 1:
		styleClass = "exchange/water-pack/components/symbol-state/running"
	elif stateValue == 2:
		styleClass = "exchange/water-pack/components/symbol-state/faulted"
	else:
		styleClass = "exchange/water-pack/components/symbol-state/stopped"
	return styleClass

def getTextStyle(stateValue):
	#return style class based on state
	
	if stateValue == 0:
		styleClass = "exchange/water-pack/components/text-state/stopped"
	elif stateValue == 1:
		styleClass = "exchange/water-pack/components/text-state/running"
	elif stateValue == 2:
		styleClass = "exchange/water-pack/components/text-state/faulted"
	else:
		styleClass = "exchange/water-pack/components/text-state/stopped"
	return styleClass
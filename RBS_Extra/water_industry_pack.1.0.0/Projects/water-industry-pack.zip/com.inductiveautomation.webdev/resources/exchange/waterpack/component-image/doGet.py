def doGet(request, session):
	component = request["params"].get('component')
	if component != None:
		import os, base64
		separator = system.util.getProperty('file.separator')
		PathParts = [
			'..'
			, 'ignition'
			, 'data'
			, 'projects'
			, system.project.getProjectName()
			, 'com.inductiveautomation.perspective'
			, 'views'
			, 'Exchange'
			, 'WaterPack'
			, 'Components'
		]
		components = os.listdir(separator.join(PathParts))
		if component in components:
			image_path = separator.join(PathParts + [component, 'thumbnail.png'])
			with open(image_path) as image_file:
				response = {'contentType': 'image/png', 'bytes': base64.b64encode(image_file.read())}
		else:
			response = {'response': "Invalid component '{0}',".format(component)}
	else:
		response = {'response': 'Error!'}
	return response
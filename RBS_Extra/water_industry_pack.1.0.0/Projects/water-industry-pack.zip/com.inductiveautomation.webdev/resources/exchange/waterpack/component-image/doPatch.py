def doPatch(request, session):

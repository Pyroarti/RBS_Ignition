def doHead(request, session):
